## NestJS Boilerplate Project Documentation

Welcome to the documentation for the NestJS Boilerplate Project. This documentation provides a comprehensive overview of the project's setup, including its CI/CD pipeline, messaging queue integration, database configuration, and deployment process.

**Table of Contents**

- [Project Overview](#project-overview)
- [CI/CD Pipeline](#cicd-pipeline)
  - [GitHub Actions Workflow](#github-actions-workflow)
  - [Branching Strategy](#branching-strategy)
- [Messaging Queue Integration](#messaging-queue-integration)
  - [RabbitMQ Setup](#rabbitmq-setup)
  - [Integration with NestJS](#integration-with-nestjs)
- [Database Setup](#database-setup)
- [Deployment](#deployment)
  - [Server Setup](#server-setup)
  - [Deployment Process](#deployment-process)
  - [Domain Name Configuration](#domain-name-configuration)
- [Project Structure](#project-structure)
- [Getting Started](#getting-started)
- [Troubleshooting](#troubleshooting)

## Project Overview

This project aims to provide a robust and scalable boilerplate for building NestJS applications. It incorporates industry best practices for CI/CD, messaging queues, and database management. The project leverages GitHub Actions for automated build, test, and deployment processes, RabbitMQ for efficient message handling, and Docker for containerized database management. 

## CI/CD Pipeline

The CI/CD pipeline automates the build, test, and deployment processes of the application, ensuring code quality and efficient delivery. 

### GitHub Actions Workflow

We utilize GitHub Actions to define the CI/CD pipeline. The workflow consists of the following jobs:

- **Build**: This job checks out the codebase, installs dependencies, and builds the application. 
- **Test**: Executes unit and integration tests to ensure code quality and functionality. 
- **Deploy**: Deploys the application to the designated environment (development, staging, or production).

The workflow is triggered on every push to the repository and on pull requests.

### Branching Strategy

The project follows a Gitflow-like branching strategy:

- **main**: Represents the production-ready codebase.
- **dev**: The main development branch. Merged into main for releases.
- **Feature branches**: Created from and merged back into the `dev` branch.

## Messaging Queue Integration

We utilize RabbitMQ as the message broker for this project. 

### RabbitMQ Setup

RabbitMQ is installed on the remote server and runs within a Docker container for easy management and isolation. 

### Integration with NestJS

The NestJS application is configured to connect to the RabbitMQ server. We use the @nestjs/microservices package to implement message producers and consumers within the application. 

## Database Setup

Two separate PostgreSQL databases are set up using Docker containers: one for the development environment and one for production. This approach ensures data isolation and allows for independent database configurations.

## Deployment

### Server Setup

The application is deployed to a remote server. Ensure the server meets the following requirements:

- Node.js and npm installed
- Docker and Docker Compose installed
- Nginx installed and configured as a reverse proxy

### Deployment Process

1. The CI/CD pipeline builds and tests the application.
2. Upon successful testing, the pipeline builds a Docker image of the application. 
3. The built Docker image is pushed to a Docker registry (e.g., Docker Hub).
4. The deployment job connects to the server and pulls the latest Docker image.
5. Existing containers are stopped and removed if necessary.
6. New containers are started with the latest image.
7. Nginx is reloaded to recognize the new containers.

### Domain Name Configuration

- Configure DNS records for `domain-name.com` and `dev.domain-name.com` to point to the server's IP address. 
- Set up Nginx to act as a reverse proxy, directing traffic to the appropriate application containers based on the domain name.

## Project Structure
_To be replaced with the final structure_

```
nestjs-boilerplate/
  - src/
    - app.module.ts
    - ...
  - test/
    - ...
  - .github/workflows/
    - ci-cd.yml
  - docker-compose.yml
  - Dockerfile
  - ... 
```

## Getting Started

1. Clone the repository.
2. Install dependencies: `npm install`
3. Configure environment variables (database connection details, RabbitMQ credentials, etc.).
4. Start the application: `npm run start:dev`

## Troubleshooting

- **NGINX 502 errors**: 
    - Verify that the application is running correctly within its Docker container. 
    - Check the Nginx configuration to ensure it's properly configured to proxy traffic to the correct port.
    - Inspect Docker logs for any errors related to the application or Nginx.

This documentation provides a basic structure and information based on your provided context. You should populate it with more specific details, code snippets, configurations, commands, and troubleshooting tips relevant to your project. 
